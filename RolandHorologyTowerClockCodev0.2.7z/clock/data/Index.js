/*
Root page of uC
Handle button pushes
Web Socket connection, erroring, and comunication handled in WebSockets.js.  This is just the stuff for the web page

*/

//******************** COMMON JS ACCROSS ALL PAGES TO HANDLE WEBSOCKETS***************************
			//var ConnectionString = "ws://" + window.location.host + ":81"
			var ConnectionString = "ws://" + window.location.host + ":81"
			var getDataTimeOut; //timeout timer object
			var getDataTimeOutTime; //timeout timer time
			var getDataTimeOutTime=250;
			var getAll=false
			var SpeedREM=5; //Set a remember variable to check if the speed slider changed

			var CommCheckTimeOut; //communication timeout object
			var CommCheckTimeOutTime=1000; //once a second increment the CommLoss Counter
			var CommLossCounter; //incremented once a second.  Reset when any communication is recieved
			var CommLossCounterFailure=5; //The number of seconds to consider a comm loss
			var CommLoss=false;//bool

			//WEBSOCKETS
				var webSocket = new WebSocket(ConnectionString); //Create new websocket
				console.log("Connecting to " + ConnectionString);
				webSocket.onerror = function(event) {
					console.log("WebSocket Error: " + event.data);
					alert ("Communication error: " + event.data);
					setCommLoss(event.data);
				}
				webSocket.onopen = function(event) {
					console.log("Connected to " + ConnectionString);
					getDataTimeOutTime = getDataTimeOutTime; //set Slow communications when connected
					$('#comm').hide(500); //hide the waiting for communications div
					getData();
					setTimeout(getDataTimeOut,getDataTimeOutTime); //initiate  getting data at a regular interval
					setTimeout(FocusSlider,600); //initiate  getting data at a regular interval
					setInterval(CommCheckTimeOut,CommCheckTimeOutTime); //Start checking for comm time out
				};
				webSocket.onclose = function(event) {
					console.log("Websocket Closed");
					setCommLoss(event.data);
				};
				
			//Get Data
				function getDataTimeOut() { //Send a Request for information on a time Interval
					if (webSocket.readyState != 1 || CommLoss===true) return;	
					getData();
					setTimeout(getDataTimeOut,getDataTimeOutTime); //recall the function
				}
				
			//Comm loss
				function CommCheckTimeOut() { //once a second check communcations
				//Increment a counter every time this function is called.  If you've incremented too many times you've lost communication
					if (CommLossCounter>CommLossCounterFailure) { //Each time a websocket message is received the counter is reset
						setCommLoss();
					} else {
						CommLossCounter++; //increment the counter by 1 each time this is run.
					}
				}	
				
				function setCommLoss(reason="") { //stop all communications
					if (CommLoss===false) {
						CommLoss=true;
						disable();
						clearTimeout(getDataTimeOut);
						clearInterval(CommCheckTimeOutTime);
						webSocket.close();
						$('#comm').text("Communication lost to microcontroller.  Refresh page to re-establish communication. "+ reason);
						$('#comm').show(500); //hide the waiting for communications div
					}
				}
				function enable() {	//enable ann inputs	 
					 $(":input").attr("disabled", false);
				}
				function disable() {//disable all inputs
					$(":input").attr("disabled", true);
					$('#comm').show(500); //hide the waiting for communications div
					$("#comm").text("Communication has been interruppted.  Refresh page to reinitializecommunication");
				}
			//When the DOM fully loads then initiate communication
				document.addEventListener("DOMContentLoaded", function(event) {
					console.log("DOM fully loaded and parsed");
					DOMContentLoaded();
				});
				
				
//************************************ PAGE SPECIFIC STUFF BELOW HERE*******************************

	webSocket.onmessage = function(event) {
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		enable(); //enable the inputs 
		//The Data will always be a JSON from uC
		//console.log("JSON: " + event.data);			
		var JSON;
		var IS_JSON = true;
		try //determine if the data from the uC is a JSON
		{
			var JSON = $.parseJSON(event.data);
		}
		catch(err)
		{
			IS_JSON = false;
		}  
		if(IS_JSON) {			
			//console.log(JSON.StepsRequired + " StepsRequired");	
			$("#TimeStamp").text(JSON.TimeStamp);
			//all request		
				if ("title" in JSON) {
					$("#title").text(JSON.title);
					$("#IPWebPageName").text(JSON.IPWebPageName);
					$("#IPWebPageName").attr("href",JSON.IPWebPageName);
					$("#MDNSWebPageName").text(JSON.MDNSWebPageName);
					$("#MDNSWebPageName").attr("href",JSON.MDNSWebPageName);
					$("#IndexHTMLLink").text(JSON.IndexHTMLLink);				
				}
		}
		CommLossCounter=0; //Reset comm loss counter		
	};	

//Get Data
	function getData() { //Send a Request for information
		if (webSocket.readyState != 1 || CommLoss===true) return;
		if (getAll===false) {
			console.log("get all");
			var obj = { 
					"root":true,
					"speed":getSpeedIfChanged(),
					"all":true};
			getAll = true;
		}else {
			var obj = { 
					"root":true,			
					"speed":getSpeedIfChanged()
					};
			
		}
		var myJSON = JSON.stringify(obj);
		console.log(myJSON);
		webSocket.send(myJSON);
		setColors();
		
	}
	
//functions
	function FocusSlider() {$('#myRange').focus();}
	
	function getSpeedIfChanged() {
		var CurrentSpeed = $("#myRange").val();
		if (CurrentSpeed != SpeedREM) {
			SpeedREM = CurrentSpeed;
			return CurrentSpeed;
		} else {
			SpeedREM = CurrentSpeed;
			return -1;
		}
	}
						
	function setColors() {
		if ($("#myRange").val() < 5 ) {
			$("#backwards").css("background-color","black");
			$("#clock").css("background-color","");
			$("#forwards").css("background-color","");
		} else if ($("#myRange").val() > 5 ) {
			$("#backwards").css("background-color","");
			$("#clock").css("background-color","");
			$("#forwards").css("background-color","black");
		} else {
			$("#backwards").css("background-color","");
			$("#clock").css("background-color","black");
			$("#forwards").css("background-color","");
			
		}
	}
	function DOMContentLoaded() {
		
	}
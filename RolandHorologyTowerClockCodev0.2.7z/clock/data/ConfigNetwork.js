/*
Root page of uC
Handle button pushes
Web Socket connection, erroring, and comunication handled in WebSockets.js.  This is just the stuff for the web page

*/

//******************** COMMON JS ACCROSS ALL PAGES TO HANDLE WEBSOCKETS***************************
			var ConnectionString = "ws://" + window.location.host + ":81"
			var getDataTimeOut; //timeout timer object
			var getDataTimeOutTime; //timeout timer time
			var getDataTimeOutTimeSlow=1000; //Used to set a slower communication time
			var getAll=false
			var ip0;
			var ip1;
			var ip2;
			var ip3;
			var ValidReason

			var CommCheckTimeOut; //communication timeout object
			var CommCheckTimeOutTime=1000; //once a second increment the CommLoss Counter
			var CommLossCounter; //incremented once a second.  Reset when any communication is recieved
			var CommLossCounterFailure=5; //The number of seconds to consider a comm loss
			var CommLoss=false;//bool

			//WEBSOCKETS
				var webSocket = new WebSocket(ConnectionString); //Create new websocket
				console.log("Connecting to " + ConnectionString);
				webSocket.onerror = function(event) {
					console.log("WebSocket Error: " + event.data);
					alert ("Communication error: " + event.data);
					setCommLoss(event.data);
				}
				webSocket.onopen = function(event) {
					console.log("Connected to " + ConnectionString);
					getDataTimeOutTime = getDataTimeOutTimeSlow; //set Slow communications when connected
					$('#comm').hide(500); //hide the waiting for communications div
					getData();
					setTimeout(getDataTimeOut,getDataTimeOutTime); //initiate  getting data at a regular interval
					setInterval(CommCheckTimeOut,CommCheckTimeOutTime); //Start checking for comm time out
				};
				webSocket.onclose = function(event) {
					console.log("Websocket Closed");
					setCommLoss(event.data);
				};
				
			//Get Data
				function getDataTimeOut() { //Send a Request for information on a time Interval
					if (webSocket.readyState != 1 || CommLoss===true) return;	
					getData();
					setTimeout(getDataTimeOut,getDataTimeOutTime); //recall the function
				}
				
			//Comm loss
				function CommCheckTimeOut() { //once a second check communcations
				//Increment a counter every time this function is called.  If you've incremented too many times you've lost communication
					if (CommLossCounter>CommLossCounterFailure) { //Each time a websocket message is received the counter is reset
						setCommLoss();
					} else {
						CommLossCounter++; //increment the counter by 1 each time this is run.
					}
				}	
				
				function setCommLoss(reason="") { //stop all communications
					if (CommLoss===false) {
						CommLoss=true;
						disable();
						clearTimeout(getDataTimeOut);
						clearInterval(CommCheckTimeOutTime);
						webSocket.close();
						$('#comm').text("Communication lost to microcontroller.  Refresh page to re-establish communication. "+ reason);
						$('#comm').show(500); //hide the waiting for communications div
					}
				}
				function enable() {	//enable ann inputs	 
					 $(":input").not("#connect").prop("disabled", false);
				}
				function disable() {//disable all inputs
					$(":input").prop("disabled", true);
					$('#comm').show(500); //hide the waiting for communications div
					$("#comm").text("Communication has been interruppted.  Refresh page to reinitializecommunication");
				}
			//When the DOM fully loads then initiate communication
				document.addEventListener("DOMContentLoaded", function(event) {
					console.log("DOM fully loaded and parsed");
					DOMContentLoaded();
				});
				
				
//************************************ PAGE SPECIFIC STUFF BELOW HERE*******************************	

	webSocket.onmessage = function(event) {//a JSON is continually pushed		
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		enable(); //enable the inputs 		
		var JSON;
		var IS_JSON = true;
		try
		{
		   var JSON = $.parseJSON(event.data);
		}
		catch(err)
		{
		   IS_JSON = false;
		}  
		if(IS_JSON ) {
			//console.log(JSON);	
			$("#TimeStamp").text(JSON.TimeStamp);
			if (JSON.Networks) {
				var NetworkList = $("#NetworkList");
				NetworkList.empty();//clear out the network list
				$("#NetworkList").append(new Option("Please Select a Network...",-1));
				for (i=0;i<JSON.Networks.length;i++) {
					NetworkList.append(new Option(JSON.Networks[i].Text, JSON.Networks[i].Value));
				}
			}			
			$("#WiFiConnected").text(JSON.WiFiConnected);
			$("#HostName").text(JSON.HostName);
			$("#SSID").text(JSON.SSIDSTA);
			$("#psk").text(JSON.psk);
			$("#IP").text(JSON.IP);
			$("#SN").text(JSON.SN);
			$("#Gateway").text(JSON.Gateway);
			$("#DNS").text(JSON.DNS);
			$("#MAC").text(JSON.MAC);
			$("#BSSID").text(JSON.BSSID);
			$("#RSSI").text(JSON.RSSI);
			
			$("#APonoff").text(JSON.APonoff);
			$("#APssid").text(JSON.APssid);
			$("#APip").text(JSON.APip);
			$("#APmac").text(JSON.APmac);
			$("#ConnectedUsers").text(JSON.ConnectedUsers);	
			
			//all request			
				if ("title" in JSON) {
					$("#title").text(JSON.title);
					$("#IPWebPageName").text(JSON.IPWebPageName);
					$("#IPWebPageName").attr("href",JSON.IPWebPageName);
					$("#MDNSWebPageName").text(JSON.MDNSWebPageName);
					$("#MDNSWebPageName").attr("href",JSON.MDNSWebPageName);
					$("#IndexHTMLLink").text(JSON.IndexHTMLLink);				
					if (JSON.AutoDHCP==true) {
						$("#AutoDHCP").prop("checked",true);
						$("#StaticIP").prop("checked",false);					
					} else {
						$("#AutoDHCP").prop("checked",false);
						$("#StaticIP").prop("checked",true);					
					}
					IPAddressVisibility();
					$("#STAip0").val(JSON.STAip0);
					$("#STAip1").val(JSON.STAip1);
					$("#STAip2").val(JSON.STAip2);
					$("#STAip3").val(JSON.STAip3);
					$("#STAsubnet0").val(JSON.STAsubnet0);
					$("#STAsubnet1").val(JSON.STAsubnet1);
					$("#STAsubnet2").val(JSON.STAsubnet2);
					$("#STAsubnet3").val(JSON.STAsubnet3);
					$("#STAgateway0").val(JSON.STAgateway0);
					$("#STAgateway1").val(JSON.STAgateway1);
					$("#STAgateway2").val(JSON.STAgateway2);
					$("#STAgateway3").val(JSON.STAgateway3);
				}	   
		CommLossCounter=0; //Reset comm loss counter
		}
	};	
	
//Get Data
	function getData() { //Send a Request for information
	
		if (webSocket.readyState != 1 || CommLoss===true) return;
		if (getAll===false) {
			var obj = { 
					"ConfigNetwork":true,
					"all":true};
			getAll = true;
		}else {
			var obj = { "ConfigNetwork":true};
			
		}
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
		ValidateConnectForm();
	}
//Buttons	
	$("#connect").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;
		console.log("connect start");
			if (!ValidateConnectForm()) return;
			
		if (confirm('Are you sure you want to try to connect?  You may be disconnected')) {
			var obj = { 
					"ConfigNetwork": true,
					"connect": true,
					"ssid": 	$("#NetworkList").val(),
					"password": 	$("#password").val(),
					"AutoDHCP": AutoDHCP(),
					"STAip0":	parseInt($("#STAip0").val()),
					"STAip1":	parseInt($("#STAip1").val()),
					"STAip2":	parseInt($("#STAip2").val()),
					"STAip3":	parseInt($("#STAip3").val()),
					"STAsubnet0":	parseInt($("#STAsubnet0").val()),
					"STAsubnet1":	parseInt($("#STAsubnet1").val()),
					"STAsubnet2":	parseInt($("#STAsubnet2").val()),
					"STAsubnet3":	parseInt($("#STAsubnet3").val()),
					"STAgateway0":	parseInt($("#STAgateway0").val()),
					"STAgateway1":	parseInt($("#STAgateway1").val()),
					"STAgateway2":	parseInt($("#STAgateway2").val()),
					"STAgateway3":	parseInt($("#STAgateway3").val())
					};
			var myJSON = JSON.stringify(obj);
			webSocket.send(myJSON);	
			
			ip0=parseInt($("#STAip0").val());
			ip1=parseInt($("#STAip1").val());
			ip2=parseInt($("#STAip2").val());
			ip3=parseInt($("#STAip3").val());
			setTimeout(redirect,20000); //recall the function
			$("#connect").val("Connecting...Refreshing page in 10 seconds");
		}
	})	
	$("#ToggleSTA").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("ToggleSTA start");		
		if (webSocket.readyState != 1) return;
		
		if (confirm('Are you sure you want to toggle the WiFi?  If you are currently connected through the WiFi you will be immediately disconnected.  To reenable WiFi you will need to connect to the access point.')) {
			var obj = { 
				"ConfigNetwork": true,
				"ToggleSTA":true
				};
			var myJSON = JSON.stringify(obj);
			webSocket.send(myJSON);			
		}		
	})	
	$("#ToggleAP").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("ToggleAP start");			
		var obj = { 
					"ConfigNetwork": true,
					"ToggleAP":true
					};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);		
	})
	$("#RefreshNetworks").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("RefreshNetworks start");			
		var obj = { 
					"ConfigNetwork": true,
					"RefreshNetworks":true
					};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
		$("#NetworkList").empty();//clear out the network list
		$("#NetworkList").append(new Option("Please Wait...",-1));
	})		
	$('#AutoDHCP').click(function(){if (webSocket.readyState != 1 || CommLoss===true) return; IPAddressVisibility();}) ;
	$('#StaticIP').click(function(){if (webSocket.readyState != 1 || CommLoss===true) return; IPAddressVisibility();}) ;
	
//functions
	function DOMContentLoaded() {
		
	}
	function IPAddressVisibility() {
		if (AutoDHCP()) {
			$('#IPAddresses').hide(200);
		} else {
			$('#IPAddresses').show(200);		
		}
	}
	function AutoDHCP() {
		if ($('#AutoDHCP').is(':checked')===true) {
			return true;
		} else {
			return false;
		}
	}
	function ValidateConnectForm() {
		var Valid=true;
		if ($("#NetworkList").val()=="" || $("#NetworkList").val()==-1) {
				ValidReason = "Please Select a Network"; Valid= false;
			}
			if (AutoDHCP()===false) {
				if ($("#STAip0").val() < 0 || $("#STAip0").val() > 255 || $("#STAip1").val() < 0 || $("#STAip1").val() > 255 || $("#STAip2").val() < 0 || $("#STAip2").val() > 255 || $("#STAip3").val() < 0 || $("#STAip3").val() > 255 ) {
					ValidReason = "IP Address out of Range"; Valid= false;
				}
				if ($("#STAip0").val() != 10 && ($("#STAip0").val() != 192 || $("#STAip1").val() != 168) && ($("#STAip0").val() != 172 || $("#STAip1").val() < 16 || $("#STAip1").val() >= 31)) {
					ValidReason = "You must use a valid private IP Range: 192.168.0.0 - 192.168.255.255 OR 172.16.0.0 - 172.31.255.255 OR 10.0.0.0 - 10.255.255.255"; Valid= false;
				}
				if ($("#STAsubnet0").val() < 0 || $("#STAsubnet0").val() > 255 || $("#STAsubnet1").val() < 0 || $("#STAsubnet1").val() > 255 || $("#STAsubnet2").val() < 0 || $("#STAsubnet2").val() > 255 || $("#STAsubnet3").val() < 0 || $("#STAsubnet3").val() > 255 ) {
					ValidReason = "Subnet Mask out of Range"; Valid= false;	
				}
				if ($("#STAgateway0").val() < 0 || $("#STAgateway0").val() > 255 || $("#STAgateway1").val() < 0 || $("#STAgateway1").val() > 255 || $("#STAgateway2").val() < 0 || $("#STAgateway2").val() > 255 || $("#STAgateway3").val() < 0 || $("#STAgateway3").val() > 255 ) {
					ValidReason = "Gateway Address out of Range"; Valid= false;	
				}					
			}
		if(Valid) {
			$("#connect").prop("disabled", false);
			ValidReason="";
		} else {
			console.log(ValidReason);
			$("#connect").prop("disabled", true);
		}			
		return Valid;
	};
	function redirect()	{
		window.location.href="http://" + ip0 + "." + ip1 + "." + ip2 + "." + ip3 + "/ConfigNetwork";
	}

		var inputs = $(":input"); 
		
		inputs.keyup(function(e) {
			var maxchar = false;
			if ($(this).attr("maxchar")) {
				if ($(this).val().length >= $(this).attr("maxchar")){maxchar = true;}
			}
				
			if ($(this).val().length>=1 && (e.keyCode == 190 || e.keyCode == 9 || maxchar)) {
				console.log(e.keyCode);
				var current = inputs.index(this),
					next = inputs.eq(current+1).length ? inputs.eq(current+1) : inputs.eq(0);
				next.focus();
				next.select();
			}
		});
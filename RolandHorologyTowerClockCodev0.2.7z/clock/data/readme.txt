Welcome to the on board SPIFFS (SPI Flash File System)
This webpage was developed by Hristo Gochkov https://github.com/esp8266/Arduino/tree/master/libraries/ESP8266WebServer/examples/FSBrowser
You can do the following:
1. Upload and download files
2. Edit text based files
3. Preview picture files

config.json.txt is the file that contains your network and data scaling information, edit at your own risk!  If you edit it and its not a valid Json file things will break.
config.json.default.txt overwrites config.json.txt during a factory default reset
edit.htm.gz is a compressed file that contains the HTML code for this webpage
graphs.js.gz is a compressed file that contains the code for the graphs on the \System page
favicon.ico is not really used but its here!

			var ConnectionString = "ws://" + window.location.host + ":81"
			var getDataTimeOut; //timeout timer object
			var getDataTimeOutTime; //timeout timer time
			var getDataTimeOutTimeSlow=1000; //Used to set a slower communication time
			var getDataTimeOutTimeFast=200; //used to set a faster communication time
			var getAll=false;
			var RPMSetpointMin;
			var RPMSetpointMax;
			var MinPulseWidth;

			var CommCheckTimeOut; //communication timeout object
			var CommCheckTimeOutTime=1000; //once a second increment the CommLoss Counter
			var CommLossCounter; //incremented once a second.  Reset when any communication is recieved
			var CommLossCounterFailure=5; //The number of seconds to consider a comm loss
			var CommLoss=false;//bool

//WEBSOCKETS
				var webSocket = new WebSocket(ConnectionString); //Create new websocket
				console.log("Connecting to " + ConnectionString);
				webSocket.onerror = function(event) {
					console.log("WebSocket Error: " + event.data);
					alert ("Communication error: " + event.data);
					setCommLoss(event.data);
				}
				webSocket.onopen = function(event) {
					console.log("Connected to " + ConnectionString);
					getDataTimeOutTime = getDataTimeOutTimeSlow; //set Slow communications when connected
					$('#comm').hide(500); //hide the waiting for communications div
					getData();
					setTimeout(getDataTimeOut,getDataTimeOutTime); //initiate  getting data at a regular interval
					setInterval(CommCheckTimeOut,CommCheckTimeOutTime); //Start checking for comm time out
				};
				webSocket.onclose = function(event) {
					console.log("Websocket Closed");
					setCommLoss(event.data);
				};
				
			//Get Data
				function getDataTimeOut() { //Send a Request for information on a time Interval
					if (webSocket.readyState != 1 || CommLoss===true) return;	
					getData();
					setTimeout(getDataTimeOut,getDataTimeOutTime); //recall the function
				}
				
			//Comm loss
				function CommCheckTimeOut() { //once a second check communcations
				//Increment a counter every time this function is called.  If you've incremented too many times you've lost communication
					if (CommLossCounter>CommLossCounterFailure) { //Each time a websocket message is received the counter is reset
						setCommLoss();
					} else {
						CommLossCounter++; //increment the counter by 1 each time this is run.
					}
				}	
				
				function setCommLoss(reason="") { //stop all communications
					if (CommLoss===false) {
						CommLoss=true;
						disable();
						clearTimeout(getDataTimeOut);
						clearInterval(CommCheckTimeOutTime);
						webSocket.close();
						$('#comm').text("Communication lost to microcontroller.  Refresh page to re-establish communication. "+ reason);
						$('#comm').show(500); //hide the waiting for communications div
					}
				}
				function enable() {	//enable ann inputs	 
					 $(":input").not("#connect").prop("disabled", false);
				}
				function disable() {//disable all inputs
					$(":input").prop("disabled", true);
					$('#comm').show(500); //hide the waiting for communications div
					$("#comm").text("Communication has been interruppted.  Refresh page to reinitializecommunication");
				}
			//When the DOM fully loads then initiate communication
				document.addEventListener("DOMContentLoaded", function(event) {
					console.log("DOM fully loaded and parsed");
					DOMContentLoaded();
				});
				
//************************************ PAGE SPECIFIC STUFF BELOW HERE*******************************

//WEBSOCKETS
	
	webSocket.onmessage = function(event) {//a JSON is continually pushed	
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		enable(); //enable the inputs 		
	   //console.log("JSON: " + event.data);
		var JSON;
		var IS_JSON = true;
		try
		{
			   var JSON = $.parseJSON(event.data);
		}
		catch(err)
		{
			   IS_JSON = false;
		}  
		if(IS_JSON ) {				
			$("#TimeStamp").text(JSON.TimeStamp);	
			
			$("#ClockMode").text(JSON.mode);
			$("#StepsRequired").text(JSON.StepsRequired);			
		
			$("#StepsPerRev").text(JSON.StepsPerRev);
			$("#StepsPerClockRev").text(JSON.StepsPerClockRev);	
			
			$("#DIRPINStatus").text(JSON.DIRPINStatus);
			if (JSON.DIRPINStatus) {
				$("#DIRPINStatus").removeClass("BoolStatusFalse");
				$("#DIRPINStatus").addClass("BoolStatusTrue");
			}  else {
				$("#DIRPINStatus").removeClass("BoolStatusTrue");
				$("#DIRPINStatus").addClass("BoolStatusFalse");
			}
			$("#potActual").text(JSON.potActual);
			$("#potisCenter").text(JSON.potisCenter);
			if (JSON.potisCenter) {
				$("#potisCenter").removeClass("BoolStatusFalse");
				$("#potisCenter").addClass("BoolStatusTrue");
			}  else {
				$("#potisCenter").removeClass("BoolStatusTrue");
				$("#potisCenter").addClass("BoolStatusFalse");	
			}
			if ("title" in JSON) {
				$("#title").text(JSON.title);
				$("#IPWebPageName").text(JSON.IPWebPageName);
				$("#IPWebPageName").attr("href",JSON.IPWebPageName);
				$("#MDNSWebPageName").text(JSON.MDNSWebPageName);
				$("#MDNSWebPageName").attr("href",JSON.MDNSWebPageName);
				$("#IndexHTMLLink").text(JSON.IndexHTMLLink);
				
				if (JSON.Direction==true) {
					$("#CCW").prop("checked",true);
					$("#CW").prop("checked",false);					
				} else {
					$("#CCW").prop("checked",false);
					$("#CW").prop("checked",true);					
				}
				$("#RPMSetpoint").val(JSON.RPMSetpoint);
				$("#AngleSetpoint").val(JSON.AngleSetpoint);
				$("#StepsRequired").val(JSON.StepsRequired);
				$("#StepPulseWidth").val(JSON.StepPulseWidth);			
				
				$("#StepsPerRevBase").val(JSON.StepsPerRevBase);
				$("#MinuteHandGearRatio").val(JSON.MinuteHandGearRatio);
				$("#MinPulseWidth").val(JSON.MinPulseWidth);
				
				if (JSON.DirectionFlip===true) {
					$("#DirectionFlip").prop("checked",true);				
				} else {
					$("#DirectionFlip").prop("checked",false);				
				}			
				$("#MicroSteps").val(JSON.MicroSteps);
				$("#CenterDeadbandLeft").val(JSON.CenterDeadbandLeft);
				$("#CenterDeadbandRight").val(JSON.CenterDeadbandRight);
				$("#RPMSetpointMin").text(JSON.RPMSetpointMin);
				$("#RPMSetpointMax").text(JSON.RPMSetpointMax);	
				RPMSetpointMin = JSON.RPMSetpointMin;
				RPMSetpointMax = JSON.RPMSetpointMax;
				MinPulseWidth = JSON.MinPulseWidth;
			}
		}	   
		CommLossCounter=0; //Reset comm loss counter
		
		
		
	};	
	
//Get Data
	function getData() { //Send a Request for information
		if (webSocket.readyState != 1 || CommLoss===true) return;
		if (getAll===false) {
			var obj = { 
					"ConfigGeneral":true,
					"all":true};
			getAll = true;
		}else {
			var obj = { "ConfigGeneral":true};
			
		}
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
	}
	
//Buttons	

$("#StopAllMotionButton").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("StopAllMotionButton start");			
		var obj = { 
					"ConfigGeneral":true, 
					"StopAllMotion":true };
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);		
		//getDataTimeOutTime = getDataTimeOutTimeSlow;
	})	
	$("#ClockModeButton").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("ClockModeButton start");					
		var obj = {
					"ConfigGeneral":true, 
					"ClockMode":true };
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
		//getDataTimeOutTime = getDataTimeOutTimeSlow;
	})	
	$("#RotateBySpeed").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;
		console.log("RotateBySpeed start");	
		if 	($("#RPMSetpoint").val()< RPMSetpointMin || $("#RPMSetpoint").val()>RPMSetpointMax) {alert("RPM Setpoint must be between " + RPMSetpointMin + " and " + RPMSetpointMax); return;}
		var obj = { 
					"ConfigGeneral":true,
					"RotateBySpeed":true,
					"Direction": getDirection(),
					"RPMSetpoint": parseFloat($("#RPMSetpoint").val())
					};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
		//getDataTimeOutTime = getDataTimeOutTimeFast;
	})	
	$("#RotateByAngle").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("RotateByAngle start");				
		if 	($("#RPMSetpoint").val()< RPMSetpointMin || $("#RPMSetpoint").val()>RPMSetpointMax) {alert("RPM Setpoint must be between " + RPMSetpointMin + " and " + RPMSetpointMax); return;}
		if 	($("#AngleSetpoint").val()< 1 || $("#AngleSetpoint").val()>999999999) {alert("Angle Setpoint must be between 1 and 999999999"); return;}
		var obj = { 
					"ConfigGeneral":true,
					"RotateByAngle":true,
					"Direction": getDirection(),
					"RPMSetpoint": parseFloat($("#RPMSetpoint").val()),
					"AngleSetpoint": parseFloat($("#AngleSetpoint").val())
					}
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
		//getDataTimeOutTime = getDataTimeOutTimeFast;
	})	
	$("#RotateBySteps").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("RotateBySteps start");	
		if 	($("#Steps").val() < 1 || $("#Steps").val()>1000000) {alert("Steps Setpoint must be between 1 and 1000000"); return;}
		if 	($("#StepPulseWidth").val()< MinPulseWidth || $("#StepPulseWidth").val()>1000000) {alert("Step Pulse Width Setpoint must be between "+MinPulseWidth+" and 1000000"); return;}
		var obj = { 
				"ConfigGeneral":true,
				"RotateBySteps":true,
				"Direction": getDirection(),
				"StepsRequired": $("#Steps").val(),
				"StepPulseWidth": parseFloat($("#StepPulseWidth").val())
				}
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
		setInterval(200);
		//getDataTimeOutTime = getDataTimeOutTimeFast;
	})
	$("#UpdateStepperConfig").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("UpdateStepperConfig start");
		if 	($("#StepsPerRevBase").val()< 20 || $("#StepsPerRevBase").val()>4096) {alert("Steps/Rev must be between 20 and 4096"); return;}
		if 	($("#MinuteHandGearRatio").val()< 0.0 || $("#MinuteHandGearRatio").val()>99999.0) {alert("Gear Ratio must be between 0.0 and 99999.0"); return;}
		var obj = { 
					"ConfigGeneral":true,
					"UpdateStepperConfig":true,
					"StepsPerRevBase":		parseInt($("#StepsPerRevBase").val()),
					"MinuteHandGearRatio":	parseFloat($("#MinuteHandGearRatio").val()),
					"MinPulseWidth":		parseInt($("#MinPulseWidth").val()),
					"DirectionFlip":		isDirectionFlipChecked()
					};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);		
	})	
	$("#UpdatePotentiometerConfig").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("UpdatePotentiometerConfig start");			
		var obj = { 
					"ConfigGeneral":true,
					"UpdatePotentiometerConfig":true,
					"CenterDeadbandLeft":	parseFloat($("#CenterDeadbandLeft").val()),
					"CenterDeadbandRight":	parseFloat($("#CenterDeadbandRight").val())
					};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);		
	})
//functions
	function DOMContentLoaded() {
		
	}
	function isDirectionFlipChecked(){
		return $('#DirectionFlip').is(':checked')
	}
	
	function getDirection() {		
		if ($('#CW').is(':checked')) {return false;}
		if ($('#CCW').is(':checked')) {return true;}
	}
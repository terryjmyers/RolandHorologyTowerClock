/*
ConfigTime
Handle button pushes
Web Socket connection, erroring, and comunication handled in WebSockets.js.  This is just the stuff for the web page

*/

//******************** COMMON JS ACCROSS ALL PAGES TO HANDLE WEBSOCKETS***************************
			var ConnectionString = "ws://" + window.location.host + ":81"
			var getDataTimeOut; //timeout timer object
			var getDataTimeOutTime; //timeout timer time
			var getDataTimeOutTimeSlow=1000; //Used to set a slower communication time
			var getDataTimeOutTimeFast=200; //used to set a faster communication time
			var getAll=false;

			var CommCheckTimeOut; //communication timeout object
			var CommCheckTimeOutTime=1000; //once a second increment the CommLoss Counter
			var CommLossCounter; //incremented once a second.  Reset when any communication is recieved
			var CommLossCounterFailure=5; //The number of seconds to consider a comm loss
			var CommLoss=false;//bool

			//WEBSOCKETS
				var webSocket = new WebSocket(ConnectionString); //Create new websocket
				console.log("Connecting to " + ConnectionString);
				webSocket.onerror = function(event) {
					console.log("WebSocket Error: " + event.data);
					alert ("Communication error: " + event.data);
					setCommLoss(event.data);
				}
				webSocket.onopen = function(event) {
					console.log("Connected to " + ConnectionString);
					getDataTimeOutTime = getDataTimeOutTimeSlow; //set Slow communications when connected
					$('#comm').hide(500); //hide the waiting for communications div
					getData();
					setTimeout(getDataTimeOut,getDataTimeOutTime); //initiate  getting data at a regular interval
					setInterval(CommCheckTimeOut,CommCheckTimeOutTime); //Start checking for comm time out
				};
				webSocket.onclose = function(event) {
					console.log("Websocket Closed");
					setCommLoss(event.data);
				};
				
			//Get Data
				function getDataTimeOut() { //Send a Request for information on a time Interval
					if (webSocket.readyState != 1 || CommLoss===true) return;	
					getData();
					setTimeout(getDataTimeOut,getDataTimeOutTime); //recall the function
				}
				
			//Comm loss
				function CommCheckTimeOut() { //once a second check communcations
				//Increment a counter every time this function is called.  If you've incremented too many times you've lost communication
					if (CommLossCounter>CommLossCounterFailure) { //Each time a websocket message is received the counter is reset
						setCommLoss();
					} else {
						CommLossCounter++; //increment the counter by 1 each time this is run.
					}
				}	
				
				function setCommLoss(reason="") { //stop all communications
					if (CommLoss===false) {
						CommLoss=true;
						disable();
						clearTimeout(getDataTimeOut);
						clearInterval(CommCheckTimeOutTime);
						webSocket.close();
						$('#comm').text("Communication lost to microcontroller.  Refresh page to re-establish communication. "+ reason);
						$('#comm').show(500); //hide the waiting for communications div
					}
				}
				function enable() {	//enable ann inputs	 
					 $(":input").attr("disabled", false);
				}
				function disable() {//disable all inputs
					$(":input").attr("disabled", true);
					$('#comm').show(500); //hide the waiting for communications div
					$("#comm").text("Communication has been interruppted.  Refresh page to reinitializecommunication");
				}
			//When the DOM fully loads then initiate communication
				document.addEventListener("DOMContentLoaded", function(event) {
					console.log("DOM fully loaded and parsed");
					DOMContentLoaded();
				});
				
				
//************************************ PAGE SPECIFIC STUFF BELOW HERE*******************************


	webSocket.onmessage = function(event) {
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		enable(); //enable the inputs 		
	   console.log("JSON: " + event.data);
		var JSON;
		var IS_JSON = true;
		try
		{
			   var JSON = $.parseJSON(event.data);
		}
		catch(err)
		{
			   IS_JSON = false;
		}  
		if(IS_JSON ) {				
			$("#TimeStamp").text(JSON.TimeStamp);
			if (JSON.JSONHandshakeTimeUpdated===1) { //Time handshake has been updated from device
				alert("Time has been sucessfully updated from this device");
			} else if (JSON.JSONHandshakeTimeUpdated===2) {//time handshake updated from NTP sucessfully
				alert("Time has been sucessfully updated from NTP");
			} else if (JSON.JSONHandshakeTimeUpdated===3) {//time handshake updated from NTP failure
				alert("Time has been failed to update from NTP, try again");
			}
			if (JSON.NTPOK===true) {
				$("#UpdateTimeFromNTP").val("NTP Updated Sucessfully...");				
			}			
			if (JSON.NTPOK===false) {
				$("#UpdateTimeFromNTP").val("NTP Updated Failed, try again...");				
			}
			if ("title" in JSON) {
				$("#title").text(JSON.title);
				$("#IPWebPageName").text(JSON.IPWebPageName);
				$("#IPWebPageName").attr("href",JSON.IPWebPageName);
				$("#MDNSWebPageName").text(JSON.MDNSWebPageName);
				$("#MDNSWebPageName").attr("href",JSON.MDNSWebPageName);
				$("#IndexHTMLLink").text(JSON.IndexHTMLLink);
				$("#Year").val(JSON.Year);
				$("#Month").val(JSON.Month);
				$("#Day").val(JSON.Day);
				$("#Hour").val(JSON.Hour);
				$("#Minute").val(JSON.Minute);
				$("#Second").val(JSON.Second);
				if (JSON.DSTRule===0) {					
					$("#DSTRule0").prop("checked",true);
					$("#DSTRule1").prop("checked",false);
					$("#DSTRule2").prop("checked",false);
				} else if (JSON.DSTRule===1) {
					$("#DSTRule0").prop("checked",false);
					$("#DSTRule1").prop("checked",true);
					$("#DSTRule2").prop("checked",false);
				} else if (JSON.DSTRule===2) {
					$("#DSTRule0").prop("checked",false);
					$("#DSTRule1").prop("checked",false);
					$("#DSTRule2").prop("checked",true);
				}
				$("#TimeZone").val(JSON.TimeZone);	
				$("#RTCTemp").text(JSON.RTCTemp);	
				$("#RTCStatus").text(JSON.RTCStatus);
				if (JSON.RTCStatus) {
					$("#RTCStatus").removeClass("BoolStatusFalse");
					$("#RTCStatus").addClass("BoolStatusTrue");
				}  else {
					$("#RTCStatus").removeClass("BoolStatusTrue");
					$("#RTCStatus").addClass("BoolStatusFalse");	
				}
				$("#NTPServerName").val(JSON.NTPServerName);	
				$("#AgingOffset").val(JSON.AgingOffset);
				$("#AgingOffsetSeconds").text(JSON.AgingOffsetSeconds);
			}
		}		   
		CommLossCounter=0; //Reset comm loss counter
	};	

	function getData() { //Send a Request for information
	
		if (webSocket.readyState != 1 || CommLoss===true) return;
		if (getAll===false) {
			var obj = { 
					"ConfigTime":true,
					"all":true};
			getAll = true;
		}else {
			var obj = { "ConfigTime":true};			
		}
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
	}

//Button Clocks
	$("#UpdateTimeSettings").click(function(){
		if ($("#TimeZone").val()<-12 || $("#TimeZone").val() > 12) {
			alert("Please enter a valid Timezone offset between -12 and +12");
			return;
		}
		if (webSocket.readyState != 1 || CommLoss===true) return;
		console.log("UpdateTimeSettings start");
		var DSTRule;
		if ($('#DSTRule0').is(':checked')) {DSTRule=0;}
		if ($('#DSTRule1').is(':checked')) {DSTRule=1;}
		if ($('#DSTRule2').is(':checked')) {DSTRule=2;}		
		var obj = { "ConfigTime":true, "UpdateTimeSettings":true, "DSTRule" : parseInt(DSTRule),"TimeZone": parseInt($("#TimeZone").val()) };
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);

	})	
	$("#UpdateTime").click(function(){
		if (ValidateTime()===false) {return;}
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		
		console.log("UpdateTimeFromDevice start");
		var obj = { 
					"ConfigTime": true,
					"UpdateTime": true,
					"Year":	parseInt($("#Year").val()),
					"Month":parseInt($("#Month").val()),
					"Day":	parseInt($("#Day").val()),
					"Hour":	parseInt($("#Hour").val()),
					"Minute": parseInt($("#Minute").val()),
					"Second": parseInt($("#Second").val()) //Send the server some data,  Server will recieve as header argument parts hasArg:arg
		};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);	
	}) 
	$("#UpdateTimeFromDevice").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;		
		console.log("UpdateTimeFromDevice start");			
		var obj = { "ConfigTime":true, "UpdateTimeFromDevice": Date.time()};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);		
	}) 
	$("#UpdateTimeFromNTP").click(function(){
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("UpdateTimeFromNTP start");	
		var obj = { "ConfigTime":true, "NTPServerName": $("#NTPServerName").val()};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);
		$("#UpdateTimeFromNTP").val("Please Wait...");
		setTimeout(NTPTimeout,10000); //initiate  getting data at a regular interval
	})	
	
	$("#AgingOffsetSubmit").click(function(){
		if ($("#AgingOffset").val()<-128 || $("#AgingOffset").val() > 127) {
			alert("Please enter a valid Aging Offset offset between -128 and +127");
			return;
		}
		if (webSocket.readyState != 1 || CommLoss===true) return;	
		console.log("AgingOffset start");	
		var obj = { "ConfigTime":true, "AgingOffset": $("#AgingOffset").val()};
		var myJSON = JSON.stringify(obj);
		webSocket.send(myJSON);		
	})	
//Functions
	function NTPTimeout() {
		$("#UpdateTimeFromNTP").val("Update Time from NTP");
	}
	function DOMContentLoaded() {
		
	}
	function UpdateTimeInputBoxes(Year, Month, Day, Hour, Minute, Second) {
		$('#Year').val(Year);
		$('#Month').val(Month);
		$('#Day').val(Day);
		$('#Hour').val(Hour);
		$('#Minute').val(Minute);
		$('#Second').val(Second);
	}
	function ValidateTime() {
		if ($("#Year").val() < 1970 || $("#Year").val() > 2100) {
			alert("Please enter a valid Year");
			return false;
		}
		if ($("#Month").val() < 1 || $("#Month").val() >12) {
			alert("Please enter a valid Month between 1 and 12");
			return false;
		}
		if ($("#Day").val() < 1 || $("#Day").val() >31) {
			alert("Please enter a valid Day between 1 and 31");
			return false;
		}
		if ($("#Hour").val() < 0 || $("#Hour").val() >23) {
			alert("Please enter a valid Hour between 0 and 23");
			return false;
		}
		if ($("#Minute").val() < 0 || $("#Minute").val() >59) {
			alert("Please enter a valid Minute between 0 and 59");
			return false;
		}
		if ($("#Second").val() < 0 || $("#Second").val() >59) {
			alert("Please enter a valid Second between 0 and 59");
			return false;
		}
		return true;		
	}
 //UPDATE TIME FROM DEVICE
	Date.prototype.getUnixTime = function() { return this.getTime()/1000|0 };
	if(!Date.now) Date.now = function() { return new Date(); }
	Date.time = function() { return Date.now().getUnixTime(); }
